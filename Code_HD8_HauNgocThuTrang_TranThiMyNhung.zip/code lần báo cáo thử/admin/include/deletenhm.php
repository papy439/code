<?php
	include "../config.php";
	if(isset($_REQUEST['MSNHM']) and $_REQUEST['MSNHM']!=""){
		$id=$_GET['MSNHM'];
		$query="DELETE FROM nguoihienmau WHERE MSNHM='$id' ";
		if(mysql_query($query)==TRUE)
	    {
	    	?><script>
            alert('Delete Success');
            window.history.go(-1);
        </script>
    <?php
		}
	 	else
	 		{
	    	?><script>
            alert('Delete Fail');
            window.history.go(-1);
        </script>
    <?php
		}
	 	die();
	 }
	// header('Location:quanlythongtinnhm.php');
?>