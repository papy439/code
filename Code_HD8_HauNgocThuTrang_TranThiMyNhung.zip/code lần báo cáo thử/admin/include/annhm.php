<?php
	include "../config.php";
	if(isset($_REQUEST['MSNHM']) and $_REQUEST['MSNHM']!=""){
		$id=$_GET['MSNHM'];
		echo "hello";
	}
?>