<div class="form-group">
                    <div class="col-md-6" style="float: left;">
                        <p style="font-weight: bold;">Trụ sở chính (Ngân hàng máu - Ngân hàng tế bào gốc):</p>
                        <p style="font-size: 14px;">Địa chỉ Trụ sở chính tại 118 Hồng Bàng, Q.5, Tp. Hồ Chí Minh.</p>
                        <p style="font-size: 14px;">Điện thoại: 028.39571342 - Fax: 38552978</p>
                        <p style="font-size: 14px;">Website: http://bthh.org.vn</p>
                        <p style="font-size: 14px;">Giấy phép: 23543/GP</p>
                        <p style="font-size: 14px;">Copyright© 2016 BVHH. All right Reserved.</p>
                    </div>
                    <div class="col-md-6" style="float: right;">
                        <p style="font-weight: bold;">Chi nhánh (Khám chữa bệnh):</p>
                        <p style="font-size: 14px;">Địa chỉ: 201 Phạm Viết Chánh, P. Nguyễn Cư Trinh, Q.1, Tp. Hồ Chí Minh</p>
                        <p style="font-size: 14px;">Điện thoại: 028.38397535 - Fax: 38256826</p>
                        <p style="font-size: 14px;">Website: http://bthh.org.vn</p>
                        <p style="font-size: 14px;">Giấy phép: 23543/GP</p>
                        <p style="font-size: 14px;">Copyright© 2016 BVHH. All right Reserved.</p>
                    </div>
                </div>