<div style="width: 100%;background-image: url('img/background.jpg');height: 200px;padding-top: 0px;">
			
			<ul style="float: left;height: auto;width: 30%;padding-left: 100px;padding-top: 20px;color: white;"><a href="https://bthh.org.vn/"><p style="color: blue">Về bthh.org.vn</p> </a><br>
<p style="color: red;">Trụ sở chính (Ngân hàng máu - Ngân hàng tế bào gốc):</p><br>
Địa chỉ Trụ sở chính tại 118 Hồng Bàng, Q.5, Tp. Hồ Chí Minh.
Điện thoại: 028.39571342 - Fax: 38552978
Website: <a href="https://bthh.org.vn/">http://bthh.org.vn</a>
Giấy phép: 23543/GP</ul>
	<ul style="float: left;height: auto;width: 20%;padding-left: 100px;padding-top: 20px;color: white;">
		<p style="color: blue">Từ khóa</p> <br>
		<a href="https://benhvien.org.vn/benh-vien/benh-vien-truyen-mau-huyet-hoc-tphcm/#">Bệnh viện chợ rẫy, Hoàn Mỹ, Phòng khám Victoria, Bệnh viện đa khoa, Bệnh viện FV, Phòng khám nhi Q1,</a>
</ul>
<ul style="height: auto;width: 20%;float: left;padding-top: 20px">
	<p style="color: red;">Chi nhánh (Khám chữa bệnh):</p><br>
	
		Địa chỉ: 201 Phạm Viết Chánh, P. Nguyễn Cư Trinh, Q.1, Tp. Hồ Chí Minh
		Điện thoại: 028.38397535 - Fax: 38256826
		Website: http://bthh.org.vn
		Giấy phép: 23543/GP
</ul>
	<ul style="height: auto;width: 23%;float: left;padding-top: 70px;">
		<a href="https://www.facebook.com/groups/1051356931604711/"><img src="img/045-facebook.png" alt="" style="height: 50px;width: 70px; border-radius: 20px;"></a>
		<a href="https://www.youtube.com/channel/UC2KPM0F8QohHwI05FQBZ8UQ"><img src="img/002-youtube.png"  style="height: 50px;width: 70px;border-radius: 20px;"></a>
		<a href="https://benhvien.org.vn/benh-vien/benh-vien-truyen-mau-huyet-hoc-tphcm/#"><img src="img/013-twitter-1.png" alt="" style="height: 50px;width: 70px;border-radius: 20px;"></a>
		<a href="https://www.google.com/+BenhvienOrgVn45"><img src="img/035-google-plus.png" alt="" style="height: 50px;width: 70px;border-radius: 20px;"></a>
	</ul>

		</div>